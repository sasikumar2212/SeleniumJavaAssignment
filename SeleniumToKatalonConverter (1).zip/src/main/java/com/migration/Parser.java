package com.migration;

import java.util.*;
import java.util.regex.*;

public class Parser {
    public static List<String> parseActions(String script) {
        List<String> actions = new ArrayList<>();

        Pattern clickPattern = Pattern.compile("By\\.id\\(\"(.*?)\"\).*?\\.click\\(\\)");
        Matcher clickMatcher = clickPattern.matcher(script);
        while (clickMatcher.find()) {
            String id = clickMatcher.group(1);
            actions.add("WebUI.click(findTestObject('Object Repository/" + id + "'))");
        }

        if (script.contains("Assert.assertEquals")) {
            actions.add("WebUI.verifyMatch(WebUI.getWindowTitle(), 'Dashboard', false)");
        }

        return actions;
    }
}
