package com.migration;

import java.io.*;
import java.nio.file.*;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        String input = new String(Files.readAllBytes(Paths.get("sample_input/SampleTest.java")));
        List<String> actions = Parser.parseActions(input);
        FileGenerator.generate(actions, "output/TestCases/MigratedTestCase.groovy");
    }
}
