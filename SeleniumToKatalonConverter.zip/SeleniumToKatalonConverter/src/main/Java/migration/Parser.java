package com.migration;

import java.util.*;
import java.util.regex.*;

public class Parser {
    public static List<String> parseActions(String seleniumScript) {
        List<String> actions = new ArrayList<>();

        if (seleniumScript.contains("click")) {
            String id = extractLocator(seleniumScript);
            actions.add("WebUI.click(findTestObject('Object Repository/" + id + "'))");
        }

        if (seleniumScript.contains("Assert.assertEquals")) {
            actions.add("WebUI.verifyMatch(WebUI.getWindowTitle(), 'Dashboard', false)");
        }

        return actions;
    }

    private static String extractLocator(String line) {
        Pattern pattern = Pattern.compile("By\\.id\\(\"(.*?)\"\\)");
        Matcher matcher = pattern.matcher(line);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "unknownLocator";
    }
}
