package com.migration;

import java.io.*;
import java.nio.file.*;
import java.util.List;

public class FileGenerator {
    public static void generateGroovy(List<String> actions, String outputFile) throws IOException {
        String template = new String(Files.readAllBytes(Paths.get("templates/katalon_template.groovy")));
        String actionBlock = String.join("\n", actions);
        String finalScript = template.replace("${actions}", actionBlock).replace("${url}", "https://example.com");

        Files.write(Paths.get(outputFile), finalScript.getBytes());
    }
}
