package com.migration;

import java.io.*;
import java.nio.file.*;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        String seleniumScript = new String(Files.readAllBytes(Paths.get("sample_input/SampleTest.java")));
        List<String> katalonActions = Parser.parseActions(seleniumScript);
        FileGenerator.generateGroovy(katalonActions, "output/TestCases/MigratedTestCase.groovy");
        System.out.println("✅ Migration complete. Check 'output/TestCases/MigratedTestCase.groovy'");
    }
}
