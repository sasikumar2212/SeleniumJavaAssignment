driver.findElement(By.id("loginBtn")).click();
Assert.assertEquals(driver.getTitle(), "Dashboard");
