package org.example;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class LoginTest {
    protected  static WebDriver driver;
    public static void main(String[] args) {

        // Set path to chromedriver executable if not in system PATH
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");


        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--display-extensions");

        // Launch browser
        driver = new ChromeDriver(options);
        

        try {
            // Navigate to login page
            driver.get("https://practicetestautomation.com/");

            // Maximize window
            driver.manage().window().maximize();

            // Enter username
            WebElement practice  = driver.findElement(By.xpath("//li/a[contains(text(), 'Practice')]"));
            practice.click();

            WebElement testLogin = driver.findElement(By.xpath("//a[contains(text(), 'Test Login Page')]"));
            testLogin.click();
            WebElement username = driver.findElement(By.id("username"));
            username.sendKeys("student");

            // Enter password
            WebElement password = driver.findElement(By.id("password"));
            password.sendKeys("Password123");

            // Click login button
            WebElement loginButton = driver.findElement(By.id("submit"));
            loginButton.click();

            // Optional: Verify login success
            Thread.sleep(2000);  // Wait for page load
            String pageTitle = driver.getTitle();
            if (pageTitle.contains("Practice Test Automation")) {
                System.out.println("Login successful!");
            } else {
                System.out.println("Login failed.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close browser
            driver.quit();
        }
    }
}
