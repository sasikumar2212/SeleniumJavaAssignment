import static com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

WebUI.openBrowser('')
WebUI.navigateToUrl('https://practicetestautomation.com/')

// TODO: Create TestObject with XPath: //li/a[contains(text(), 'Practice')]
WebUI.click(findTestObject('Object Repository///li/a[contains(text(), 'Practice')]'))
// TODO: Create TestObject with XPath: //a[contains(text(), 'Test Login Page')]
WebUI.click(findTestObject('Object Repository///a[contains(text(), 'Test Login Page')]'))
WebUI.setText(findTestObject('Object Repository/username'), "student")
WebUI.setText(findTestObject('Object Repository/password'), "Password123")
WebUI.verifyMatch(WebUI.getWindowTitle(), "Logged In Successfully | Practice Test Automation", false)

WebUI.closeBrowser()
