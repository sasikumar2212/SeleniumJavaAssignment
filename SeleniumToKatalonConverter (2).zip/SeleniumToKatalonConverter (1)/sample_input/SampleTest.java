driver.findElement(By.xpath("//li/a[contains(text(), 'Practice')]")).click();
driver.findElement(By.xpath("//a[contains(text(), 'Test Login Page')]")).click();
driver.findElement(By.id("username")).sendKeys("student");
driver.findElement(By.id("password")).sendKeys("Password123");
driver.findElement(By.id("submit"))click();
Assert.assertEquals(driver.getTitle(), "Logged In Successfully | Practice Test Automation");


