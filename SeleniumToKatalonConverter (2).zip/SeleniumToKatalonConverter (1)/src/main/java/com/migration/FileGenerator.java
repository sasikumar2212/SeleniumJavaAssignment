package com.migration;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class FileGenerator {
    public static void generate(List<String> actions, String outputPath) throws IOException {
        String template = new String(Files.readAllBytes(Paths.get("templates/katalon_template.groovy")));
        String script = template.replace("${actions}", String.join("\n", actions))
                                .replace("${url}", "https://practicetestautomation.com/");

        Files.write(Paths.get(outputPath), script.getBytes());
        System.out.println("✅ Generated: " + outputPath);
    }
}
