package com.migration;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Parser {
    public static List<String> parseActions(String script) {
        List<String> actions = new ArrayList<>();

        // Handle click using By.id
        Pattern clickPattern = Pattern.compile("By\\.id\\(\"(.*?)\"\\).*?\\.click\\(\\)");
        Matcher clickMatcher = clickPattern.matcher(script);
        while (clickMatcher.find()) {
            String id = clickMatcher.group(1);
            actions.add("WebUI.click(findTestObject('Object Repository/" + id + "'))");
        }

        // Handle click using By.xpath
        Pattern clickByXpath = Pattern.compile("driver\\.findElement\\(By\\.xpath\\(\"(.*?)\"\\)\\)\\.click\\(\\);");
        Matcher clickXpathMatcher = clickByXpath.matcher(script);
        while (clickXpathMatcher.find()) {
            String xpath = clickXpathMatcher.group(1);
            actions.add("// TODO: Create TestObject with XPath: " + xpath);
            actions.add("WebUI.click(findTestObject('Object Repository/"+ xpath +"'))");
        }

        // Handle sendKeys using By.id
        Pattern sendKeysById = Pattern.compile("driver\\.findElement\\(By\\.id\\(\"(.*?)\"\\)\\)\\.sendKeys\\(\"(.*?)\"\\);");
        Matcher sendKeysIdMatcher = sendKeysById.matcher(script);
        while (sendKeysIdMatcher.find()) {
            String id = sendKeysIdMatcher.group(1);
            String value = sendKeysIdMatcher.group(2);
            actions.add("WebUI.setText(findTestObject('Object Repository/" + id + "'), \"" + value + "\")");
        }

       // Handle sendKeys using By.xpath
        Pattern sendKeysByXpath = Pattern.compile("driver\\.findElement\\(By\\.xpath\\(\"(.*?)\"\\)\\)\\.sendKeys\\(\"(.*?)\"\\);");
        Matcher sendKeysXpathMatcher = sendKeysByXpath.matcher(script);
        while (sendKeysXpathMatcher.find()) {
            String xpath = sendKeysXpathMatcher.group(1);
            String value = sendKeysXpathMatcher.group(2);
            actions.add("// TODO: Create TestObject with XPath: " + xpath);
            actions.add("WebUI.setText(findTestObject('Object Repository/"+xpath+"'), \"" + value + "\")");
        }

        // if (script.contains("Assert.assertEquals")) {
        //     actions.add("WebUI.verifyMatch(WebUI.getWindowTitle(), 'Logged In Successfully | Practice Test Automation', false)");
        // }

        // Handle Assert.assertEquals(driver.getTitle(), "ExpectedTitle")
        Pattern assertTitle = Pattern.compile("Assert\\.assertEquals\\(driver\\.getTitle\\(\\),\\s*\"(.*?)\"\\);");
        Matcher assertMatcher = assertTitle.matcher(script);
        while (assertMatcher.find()) {
            String expectedTitle = assertMatcher.group(1);
            actions.add("WebUI.verifyMatch(WebUI.getWindowTitle(), \"" + expectedTitle + "\", false)");
        }

        return actions;
    }
}
